# Dempster shafer theory

Python package